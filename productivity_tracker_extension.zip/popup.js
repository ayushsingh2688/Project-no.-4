
document.addEventListener('DOMContentLoaded', function () {
  chrome.storage.local.get('siteTime', function (data) {
    const output = document.getElementById('data');
    const siteTime = data.siteTime || {};
    for (let site in siteTime) {
      output.innerHTML += `<p>${site}: ${siteTime[site].length} visits</p>`;
    }
  });
});
