
let siteTime = {};

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.active) {
    const domain = new URL(tab.url).hostname;
    const now = Date.now();
    siteTime[domain] = siteTime[domain] || [];
    siteTime[domain].push(now);
    chrome.storage.local.set({ siteTime });
  }
});
